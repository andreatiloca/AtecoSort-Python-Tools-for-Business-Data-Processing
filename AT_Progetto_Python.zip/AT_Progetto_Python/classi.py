class Impresa:
    def __init__(self, codice_fiscale, denominazione, ragione_sociale, ateco,num_dipedenti,num_soci,num_amministratori,data_costituzione,
                 certificato_qualità,fatturato):
        self.codice_fiscale = codice_fiscale
        self.denominazione = denominazione
        self.ragione_sociale = ragione_sociale
        self.ateco = ateco
        self.num_dipedenti = int(num_dipedenti)
        self.num_soci = int(num_soci)
        self.num_amministratori = int(num_amministratori)
        self.data_costituzione = data_costituzione
        self.certificato_qualità = bool(int(certificato_qualità))
        self.fatturato = float(fatturato)

    def diritto_agevolazione(self):
        """In questa funzione facciamo una verifica dei requisiti per lo sconto sull'irap"""
        return self.num_dipedenti > 15 and self.ateco == "A03" #Condizioni riportate nella consegna

    def calcolo_irap(self):
        """Calcolo dell'irap secondo i range di fatturazione"""
        if 10000 <= self.fatturato < 50000:
            coefficiente = 1.2
            aliquota = 0.0049
        elif 50000 <= self.fatturato < 150000:
            coefficiente = 1.5
            aliquota = 0.0076
        else:  # Fatturato >= 150000
            coefficiente = 1.7
            aliquota = 0.0081

        base_imponibile = self.fatturato * coefficiente
        irap = base_imponibile * aliquota

        # Se l'impresa ha diritto all'agevolazione, si applica uno sconto del 1.5%
        if self.diritto_agevolazione():
            irap *= 0.985  # 98.5% dell'IRAP normale

        return round(irap, 2)  # Arrotondamento a due decimali
    
    def scheda_impresa(self):
        """Funzione che si ispira a quella fatta a lezione. Permette di vedere i dati di un'impresa
        presente in un registro"""
        scheda = f"""
        CF: {self.codice_fiscale}
        Denominazione: {self.denominazione}
        Codice Ateco: {self.ateco}
        Num Dipendenti: {self.num_dipedenti}
        Num Soci: {self.num_soci}
        Num Amministratori: {self.num_amministratori}
        Data Costituzione: {self.data_costituzione}
        Certificato di Qualità: {self.certificato_qualità}
        Fatturato: {self.fatturato}
        """
        return scheda
    
    def modifica_info_aziende(self):
        """La seguente funzione permette di cambiare o aggiornare i dati di un'impresa
        presente nel registro. Esempio classico: cambio del numero di risorse umane ecc."""
        print(""" Modifica le informazioni di un'azienda presente nella lista:
              1 - Codice Fiscale
              2 - Denominazione
              3 - Ragione Sociale
              4 - Codice Ateco
              5 - Numero Dipendenti
              6 - Numero Soci
              7 - Numero Amministratori
              8 - Data Costituzione
              9 - Certificato di Qualità    
              10 - Fatturato """)
        
        scelta = input("Scegli l'operazione da eseguire: ")
        if scelta == "1":
            self.codice_fiscale = input("Nuovo Codice Fiscale? = ")
        elif scelta == "2":
            self.denominazione = input("Nuovo Denominazione? = ")
        elif scelta == "3":
            self.ragione_sociale = input("Nuova Ragione Sociale? = ")
        elif scelta == "4":
            self.ateco = input("Nuova Codice Ateco? = ")
        elif scelta == "5":
            self.num_dipedenti = input("Nuova Numero Dipendenti? = ")
        elif scelta == "6":
            self.num_soci = input("Nuova Numero Soci? = ")
        elif scelta == "7":
            self.num_amministratori = input("Nuova Numero Amministratori? = ")
        elif scelta == "8":
            self.data_costituzione = input("Nuova Data Costituzione? = ")
        elif scelta == "9":
            self.certificato_qualità = input("Nuova Certificato di Qualità ? = ")
        elif scelta == "10":
            self.fatturato = input("Nuova Fatturato? = ")
        else:
            print("Scelta errata!")



class f24():
    def __init__(self, impresa,anno):
        self.impresa = impresa
        self.importo_irap = impresa.calcolo_irap()
        self.anno = anno
        
    def modulo_f24(self):
        """La funzione stampa un semplice modulo sullo stile f24"""
        return f"""
        Modello F24 - Anno {self.anno}
        ---------------------------------
        Impresa: {self.impresa.denominazione}
        Codice Fiscale: {self.impresa.codice_fiscale}
        Codice ATECO: {self.impresa.ateco}
        Fatturato: {self.impresa.fatturato} €
        Importo IRAP dovuto: {self.importo_irap} €
        ---------------------------------
        """
    

    
class Comune:
    def __init__(self, comune):
        self.comune = str(comune)
        self.imprese_registrate = []
        self.modelli_f24_emessi = [] 

    # 1. Registrazione di una nuova impresa presso il comune
    def registra_impresa(self, impresa):
        self.imprese_registrate.append(impresa) #registro di imprese registrate in un comune inserite una di seguito all'altra
        print(f"Impresa '{impresa.denominazione}' registrata con successo nel comune di {self.comune}.")

    # 2. Emissione F24 per un determinato anno
    def emetti_modello_f24(self, impresa, anno):
        """Genera e registra un modello F24 per il pagamento IRAP"""
        if impresa not in self.imprese_registrate:  #In questo caso usiamo questa condizione per 
            #evitare di bloccare il codice nel caso un impresa inserita non fosse registrata nel comune
            print(f"Errore: L'impresa '{impresa.denominazione}' non è registrata nel comune di '{self.comune}'.")
            print("Attenzione a maiuscole e spazi!")
            return None

        modello_f24 = f24(impresa, anno) #richiamo la funzione di f24 rispetto a un certo anno
        self.modelli_f24_emessi.append(modello_f24)  # Correzione qui
        print(f"Modello F24 emesso per l'impresa '{impresa.denominazione}' per l'anno {anno}.")
        return modello_f24
    # 3. Stampa dei modelli f24 delle imprese presenti nel comune
    def stampa_modelli_f24(self):
        if not self.modelli_f24_emessi: #Di nuovo verifica presenza impresa
            print("Nessun modello F24 emesso.")
            return
        
        print(f"\nModelli F24 emessi nel comune di {self.comune}:\n" + "-"*40)
        for modello in self.modelli_f24_emessi: #stampo tutti i moduli f24 emessi dal comune
            print(modello.modulo_f24()) 

    #4. Calcolo del totale dell'irap riscosso da un certo comune
    def totale_irap_riscosso(self):
        totale = sum(modello.importo_irap for modello in self.modelli_f24_emessi)  #somma dell'irap versata in funzione degli f24 emessi
        #dal comune
        return round(totale, 2)

