import classi
import re
# Nome del file da cui pescare la lista delle mie imprese
nome_file = input('Inserisci il nome della cartella da aprire: ').strip()
#file_path = "dati_imprese_ordinate"
# Lista per memorizzare le imprese
imprese = []
pattern_separatore = r"[,.\|;\t]"  

# Lettura del file e creazione degli oggetti Impresa
try:
    with open(nome_file, "r", encoding="utf-8") as file:
        for riga in file:
            dati = re.split(pattern_separatore, riga.strip())
            impresa = classi.Impresa(
            codice_fiscale=dati[0],
            denominazione=dati[1],
            ragione_sociale=dati[2],
            ateco=dati[3],
            num_dipedenti=int(dati[4]),
            num_soci=int(dati[5]),
            num_amministratori=int(dati[6]),
            data_costituzione=dati[7],
            certificato_qualità=dati[8] == "True",
            fatturato=float(dati[9])
        )
            imprese.append(impresa)
except FileNotFoundError:
        print("File non trovato. Il nome del file è errato!")
except PermissionError:
    print("Non hai i permessi per accedere a questo file.")
except Exception as e:
    print(f"Errore imprevisto: {e}")
# Dizionario per memorizzare i comuni già creati
comuni = {}

interrompi = 0
while interrompi == 0:
    # Mostrare l'elenco delle imprese disponibili
    print("\nElenco delle imprese disponibili:")
    for i, impresa in enumerate(imprese):
        print(f"{i + 1}. {impresa.denominazione} ({impresa.codice_fiscale})") #questo print serve per scegliere quale impresa registrare nel comune scelto

    try:
        scelta = int(input("\nSeleziona il numero della riga nel file a cui fare riferimento: ")) - 1
        if 0 <= scelta < len(imprese):
            impresa_scelta = imprese[scelta]
            print(f"\nHai selezionato: {impresa_scelta.denominazione}")
        
            # Richiesta del nome del comune e normalizzazione maiuscole/minuscole
            nome_comune = input('Inserisci il nome del comune in cui registrare l’impresa: ').strip().capitalize()

            # Se il comune esiste già, lo riutilizziamo per il conteggio del numero di imprese registrate
            if nome_comune in comuni:
                comune = comuni[nome_comune]
            else:
                comune = classi.Comune(nome_comune)
                comuni[nome_comune] = comune  # Salviamo il comune nella lista
        
            # Registrazione dell'impresa nel comune
            comune.registra_impresa(impresa_scelta)
        
            # Calcolo dell'IRAP
            irap_importo = impresa_scelta.calcolo_irap()
            print(f"\nImporto IRAP calcolato per {impresa_scelta.denominazione}: {irap_importo} €")
        
            # Emissione del modello F24
            anno_di_riferimento = input
            modello_f24 = comune.emetti_modello_f24(impresa_scelta, 2023)
        
            # Stampa dei modelli F24 emessi
            comune.stampa_modelli_f24()
        
            # Report finale aggiornato
            print("\n--- Report Comune ---")
            print(f"Comune: {comune.comune}")
            print(f"Numero imprese registrate: {len(comune.imprese_registrate)}")
            print(f"Totale IRAP riscosso: {comune.totale_irap_riscosso()} €")

            # Opzione per ripetere il processo
            scelta_finale = input("\nVuoi registrare una nuova impresa in un altro comune? (Y/N): ").strip().lower()
            if scelta_finale == "n" or scelta_finale == "2":
                interrompi = 1
        else:
            print("\nScelta non valida! Inserisci un numero valido.")

    except ValueError:
        print("\nErrore! Inserisci un numero valido.")