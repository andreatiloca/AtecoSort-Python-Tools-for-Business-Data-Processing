import pandas as pd 
#Esercizio 2

nome_file = input('Inserisci il nome della cartella da aprire:   ').strip()
#nome_file = 'dati_imprese_ordinate'
try:
    df = pd.read_csv(nome_file, header=None, names=[
        "Codice Fiscale", "Denominazione", "Ragione Sociale", "ATECO",
        "Numero Dipendenti", "Numero Soci", "Numero Amministratori",
        "Data Costituzione", "Certificazioni di Qualità", "Fatturato"
    ])
except FileNotFoundError:
        print("File non trovato. Il nome del file è errato!")
except PermissionError:
    print("Non hai i permessi per accedere a questo file.")
except Exception as e:
    print(f"Errore imprevisto: {e}")
    
print(df)
#Punto 1
df["Numero Dipendenti"] = df["Numero Dipendenti"].astype(int)
df["Numero Soci"] = df["Numero Soci"].astype(int)
# Estrai i valori della colonna e convertili in numeri interi
media_dipendenti = sum(df["Numero Dipendenti"])/len(df)
media_soci = sum(df["Numero Soci"])/len(df)
print(f"Media dipendenti: {round(media_dipendenti,2)}; media soci: {round(media_soci,2)}")

#Punto 2
#cerchiamo le aziende con certificato di qualità = True e fatturato entro l'intervallo riportato
condizione = (df["Certificazioni di Qualità"].astype(bool)) | ((df["Fatturato"].astype(float) >= 10000) & (df["Fatturato"].astype(float) <= 50000))
contatore = condizione.sum()
# Calcoliamo la percentuale
percentuale = contatore / len(df)

# Stampa il risultato
print(f"Percentuale imprese con certificato di qualità e fatturato fra 10000 e 50000: {round(percentuale,3)}")

#Punto 3
# Filtriamo le aziende con certificazioni di qualità e ragione sociale "Società di Capitale"
aziende_filtrate = df[(df["Certificazioni di Qualità"].astype(bool) == True) & (df["Ragione Sociale"] == "Società di Capitale")]
print("\n Aziende con certificazioni di qualità e Società di Capitale:")
print(aziende_filtrate)

#Punto 4
#Numero di imprese per codice ATECO
df['ATECO'] #veloce print dei codici ateco presenti in df
conteggio_ateco = df["ATECO"].value_counts()#conteggio rispetto ai diversi codici ateco
print(conteggio_ateco)
