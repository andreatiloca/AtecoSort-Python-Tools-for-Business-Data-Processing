I seguenti file sono organizzati di modo che in:
- classi: siano presenti esclusivamente le classi generate seguendo la traccia A
- primo programma: programma eseguibile che risponde al primo test. Prende in ingresso un file di testo e ne genera uno in output in cui le imprese presenti nel documento vengono ordinate rispetto al codice ateco.
- secondo programma: programma eseguibile in cui si eseguono delle operazioni di calcolo sul file generato nel primo programma
- terzo programma: il terzo programma crea uno o più comuni ed esegue le operazioni della terza consegna.

All'interno della cartella sono anche riportati due file di testo: 
- lista_imprese_test.txt  --> input per il primo programma
- dati_imprese_ordinate.txt  --> output del primo programma e input per i successivi due

