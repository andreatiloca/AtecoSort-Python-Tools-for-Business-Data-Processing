import classi #Importo le classi generate
import re
# Esercizio 1

def leggi_file_testo(nome_file):
#La prima funzione legge un file riportato come input in modalità lettura e ne stampa il contenuto
    try:
        with open(nome_file, "r") as f:
            contenuto = f.read()
            print(contenuto)
    #Di seguito ho ripreso il metodo di check degli errori visto a lezione
    except FileNotFoundError:
        print("File non trovato. Il nome del file è errato!")
    except PermissionError:
        print("Non hai i permessi per accedere a questo file.")
    except Exception as e:
        print(f"Errore imprevisto: {e}")
    
def crea_lista_e_dizionario(nome_file):
    imprese = []
    dizionario = {}
    #Avendo il dubbio sui possibili separatori dei dati nel file, 
    #utilizziamo la regex per considerare dei possibili separatori.
    pattern_separatore = r"[,.\|;\t]"  

    with open(nome_file, "r") as f:
        for riga in f:
            dati = re.split(pattern_separatore, riga.strip())  # divido ogni riga rispetto al separatore. 
            #nel mio esempio ho usato solo le , ma ho provato questo metodo per compensare possibili errori
            
            if len(dati) != 10:  # Check della presenza di 10 elementi per ogni riga
                print(f"Riga non valida: {riga.strip()} → Saltata!")
                continue

            impresa = classi.Impresa(*dati) #Creo oggetti Impresa per ogni riga = dati di un impresa
            imprese.append(impresa) #creo il mio registro di oggetti impresa
            dizionario[impresa.codice_fiscale] = (
                impresa.num_amministratori + impresa.num_dipedenti + impresa.num_soci
            ) #dizionario che uso per rispondere a uno dei punti

    return imprese, dizionario


def salva_lista_ordinata(nome_file, lista_imprese):
    '''Funzione per salvare i dati dopo averli ordinati in base al codice ateco (o # amministratori decrescente se stesso ateco)'''
    with open(nome_file, "w", encoding="utf-8") as f:
        for impresa in lista_imprese:
            riga = f"{impresa.codice_fiscale},{impresa.denominazione},{impresa.ragione_sociale},{impresa.ateco},{impresa.num_dipedenti},{impresa.num_soci},{impresa.num_amministratori},{impresa.data_costituzione},{impresa.certificato_qualità},{impresa.fatturato}\n"
            f.write(riga)

nome_file = 'lista_imprese_test.txt'
dati = leggi_file_testo(nome_file)

#Punto 1 lista e dizionario
lista_imprese,dizionario_imprese = crea_lista_e_dizionario(nome_file)

# Stampiamo la lista delle imprese
for impresa in lista_imprese:
    print(f"{impresa.denominazione} - CF: {impresa.codice_fiscale} - Fatturato: {impresa.fatturato} €")

# Stampiamo il dizionario dei totali
print("\nDizionario delle imprese con numero totale di persone:")
for codice_fiscale, totale in dizionario_imprese.items():
    print(f"CF: {codice_fiscale} → Totale persone: {totale}")

#ordinamento delle imprese in lista rispetto al codice ATECO e in ordine decrescente 
#di num di amministratori se stesso codice ateco per due o più imprese
lista_imprese.sort(key=lambda Impresa: (Impresa.ateco, -Impresa.num_amministratori))
print("\nLista imprese ordinate per codice ATECO:")
for impresa in lista_imprese:
    print(f"{impresa.denominazione} - ATECO: {impresa.ateco} - CF: {impresa.codice_fiscale}")
    print(impresa.scheda_impresa())


salva_lista_ordinata('dati_imprese_ordinate', lista_imprese) #salvataggio dell'output

